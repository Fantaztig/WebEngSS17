/**
 * Typen der Steuerungselemente
 */
export enum ControlType {
  boolean = 0,
  enum = 1,
  continuous = 2
}
