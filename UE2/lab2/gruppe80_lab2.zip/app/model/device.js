"use strict";
/**
 * Definition eines Gerätes zur Repräsentation eines existierenden Smart Devices
 */
var Device = (function () {
    function Device() {
    }
    return Device;
}());
exports.Device = Device;
//# sourceMappingURL=device.js.map